Status: [![Build Status](http://jenkins.lutraconsulting.co.uk:8081/buildStatus/icon?job=FLO-2D%20plugin%20repo)](http://jenkins.lutraconsulting.co.uk:8080/job/FLO-2D%20plugin%20repo/)


# qgis-flo-2d-plugin
A plugin for pre-processing/post-processing FLO-2D models
