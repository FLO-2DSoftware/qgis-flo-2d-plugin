
Geopackage Structure
====================

Original files and their destination in GeoPackage

#. ``FPLAIN.DAT`` -> ``grid``
#. ``CONT.DAT`` -> ``cont``
#. ``TOLER.DAT`` -> ``toler``
#. ``MANNINGS_N.DAT`` -> currently not supported (roughness is read from FPLAIN.DAT)
#. ``TOPO.DAT`` -> currently not supported (coordinates are read from CADPTS.DAT)
#. ``INFLOW.DAT`` -> 